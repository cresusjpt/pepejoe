package com.saltechdigital.dliver

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class TimeLineActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_time_line)
    }
}
